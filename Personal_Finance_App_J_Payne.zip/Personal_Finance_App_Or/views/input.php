<?php
session_start;
?>
    <div class="input">
	    <button data-target="modal1" class="btn modal-trigger">Modal</button>
          <p>Insert a New Transaction</p>
				Date: <input type="text" id="date" value="2016-05-25"/> 
				Trans Description: <input type="text" id="trans_description" value="Something"/>
                Deposit: <input type="text" id="deposit"/>
                Expense: <input type="text" id="expense"/>
				<input type="button" value="Submit" id="addInfo"/>
			</div>
