-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2016 at 02:50 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se251`
--
CREATE DATABASE IF NOT EXISTS `se251` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `se251`;

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
CREATE TABLE `cars` (
  `carID` int(11) NOT NULL,
  `carMake` varchar(50) DEFAULT NULL,
  `carModel` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`carID`, `carMake`, `carModel`) VALUES
(1, 'Ford', 'Fiesta'),
(2, 'Ford', 'Focus'),
(3, 'Hyundai', 'Tucson'),
(4, 'Hyundai', 'Accent'),
(5, 'Honda', 'Civic'),
(6, 'Kia', 'Rio'),
(7, 'Kia', 'Soul'),
(8, 'Toyota', 'Prius'),
(9, 'Toyota', 'Yaris'),
(10, 'Nissan', 'Sentra'),
(11, 'Ford', 'F150'),
(12, 'Ford', 'F150');

-- --------------------------------------------------------

--
-- Table structure for table `fin_cc`
--

DROP TABLE IF EXISTS `fin_cc`;
CREATE TABLE `fin_cc` (
  `Tran_ID` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Trans_Description` varchar(200) NOT NULL,
  `Deposit` decimal(10,2) NOT NULL,
  `Expenses` decimal(10,2) NOT NULL,
  `Balance` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fin_cc`
--

INSERT INTO `fin_cc` (`Tran_ID`, `Date`, `Trans_Description`, `Deposit`, `Expenses`, `Balance`) VALUES
(1, '2016-05-18', 'Starting Balance', '0.00', '0.00', '0.00'),
(2, '2016-05-25', 'Deposit', '500.00', '0.00', '500.00'),
(3, '2016-05-25', 'Shell', '0.00', '23.41', '476.59');

-- --------------------------------------------------------

--
-- Table structure for table `fin_check`
--

DROP TABLE IF EXISTS `fin_check`;
CREATE TABLE `fin_check` (
  `Trans_ID` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Trans_Description` varchar(200) NOT NULL,
  `Deposit` decimal(10,2) NOT NULL,
  `Expense` decimal(10,2) NOT NULL,
  `Balance` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fin_check`
--

INSERT INTO `fin_check` (`Trans_ID`, `Date`, `Trans_Description`, `Deposit`, `Expense`, `Balance`) VALUES
(1, '2016-05-18', 'Starting Balance', '0.00', '0.00', '0.00'),
(2, '2016-05-15', 'Payroll', '500.52', '0.00', '500.52'),
(3, '2016-05-18', 'Cable Bill', '0.00', '125.42', '375.10'),
(4, '2016-05-18', 'Shell', '0.00', '20.00', '355.10'),
(5, '2016-05-18', 'Food', '0.00', '14.47', '340.63');

-- --------------------------------------------------------

--
-- Table structure for table `fin_save`
--

DROP TABLE IF EXISTS `fin_save`;
CREATE TABLE `fin_save` (
  `Trans_ID` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Trans_Description` varchar(200) NOT NULL,
  `Deposit` decimal(10,2) NOT NULL,
  `Expenses` decimal(10,2) NOT NULL,
  `Balance` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fin_save`
--

INSERT INTO `fin_save` (`Trans_ID`, `Date`, `Trans_Description`, `Deposit`, `Expenses`, `Balance`) VALUES
(1, '2016-05-18', 'Starting Balance', '0.00', '0.00', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `scores`
--

DROP TABLE IF EXISTS `scores`;
CREATE TABLE `scores` (
  `id` int(11) NOT NULL,
  `name` varchar(75) NOT NULL,
  `score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scores`
--

INSERT INTO `scores` (`id`, `name`, `score`) VALUES
(1, 'Joe', 55),
(2, 'Dan', 95),
(9, 'James', 100),
(10, 'George', 78),
(11, 'Laura', 87),
(12, 'Donald', 64),
(19, 'Dilbert', 93),
(20, 'Tom', 80),
(21, 'John', 92),
(22, 'Gil', 94),
(23, 'Billy', 96);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`carID`);

--
-- Indexes for table `fin_cc`
--
ALTER TABLE `fin_cc`
  ADD PRIMARY KEY (`Tran_ID`);

--
-- Indexes for table `fin_check`
--
ALTER TABLE `fin_check`
  ADD PRIMARY KEY (`Trans_ID`);

--
-- Indexes for table `fin_save`
--
ALTER TABLE `fin_save`
  ADD PRIMARY KEY (`Trans_ID`);

--
-- Indexes for table `scores`
--
ALTER TABLE `scores`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `carID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `fin_cc`
--
ALTER TABLE `fin_cc`
  MODIFY `Tran_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `fin_check`
--
ALTER TABLE `fin_check`
  MODIFY `Trans_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `fin_save`
--
ALTER TABLE `fin_save`
  MODIFY `Trans_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `scores`
--
ALTER TABLE `scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
