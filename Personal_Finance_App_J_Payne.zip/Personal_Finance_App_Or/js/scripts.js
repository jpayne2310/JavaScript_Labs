var carryOver;
function printInfo()
{
	var str = "";
	
	$.getJSON( "finance.php", {action:"list_check"},  function( fin_check ) {
		str = "";
		for (i=0; i< fin_check.Result.length; i++)
        {
			str += "<div class='col s2'>" + fin_check.Result[i].Date + "</div>";
			$("#results").html(str);
			str += "<div class='col s2'>" + fin_check.Result[i].Trans_Description + "</div>";
			$("#results").html(str);
			str += "<div class='col s1'>" + fin_check.Result[i].Deposit + "</div>";
			$("#results").html(str);
			str += "<div class='col s1'>" + fin_check.Result[i].Expense + "</div>";
			$("#results").html(str);
			str += "<div class='col s1'>" + fin_check.Result[i].Balance + "</div>";
			//carryOver = parseFloat(fin_check.Result[0].Balance);
			$("#results").html(str);
			str += "<br>";
			$("#results").html(str);
		}
		carryOver = parseFloat(fin_check.Result[0].Balance);
    });

	$.getJSON( "finance.php", {action:"list_saving"},  function( fin_saving ) {
		str = "";
		for (i=0; i< fin_saving.Result2.length; i++)
        {
			str += "<div class='col s2'>" + fin_saving.Result2[i].SA_Trans_DTP + "</div>";
			$("#results2").html(str);
			str += "<div class='col s2'>" + fin_saving.Result2[i].SA_Trans_Description + "</div>";
			$("#results2").html(str);
			str += "<div class='col s1'>" + fin_saving.Result2[i].SA_Deposit + "</div>";
			$("#results2").html(str);
			str += "<div class='col s1'>" + fin_saving.Result2[i].SA_Expense + "</div>";
			$("#results2").html(str);
			str += "<div class='col s1'>" + fin_saving.Result2[i].SA_Balance + "</div>";
			//carryOver = parseFloat(fin_check.Result[0].Balance);
			$("#results2").html(str);
			str += "<br>";
			$("#results2").html(str);
		}
		carryOver2 = parseFloat(fin_saving.Result2[0].SA_Balance);
    });
;
	$.getJSON( "finance.php", {action:"list_cc"},  function( fin_cc ) {
		str = "";
		for (i=0; i< fin_cc.Result3.length; i++)
        {
			str += "<div class='col s2'>" + fin_cc.Result3[i].CC_Trans_DTP + "</div>";
			$("#results3").html(str);
			str += "<div class='col s2'>" + fin_cc.Result3[i].CC_Trans_Description + "</div>";
			$("#results3").html(str);
			str += "<div class='col s1'>" + fin_cc.Result3[i].CC_Deposit + "</div>";
			$("#results3").html(str);
			str += "<div class='col s1'>" + fin_cc.Result3[i].CC_Expense + "</div>";
			$("#results3").html(str);
			str += "<div class='col s1'>" + fin_cc.Result3[i].CC_Balance + "</div>";
			//carryOver = parseFloat(fin_check.Result[0].Balance);
			$("#results3").html(str);
			str += "<br>";
			$("#results3").html(str);
		}
		carryOver3 = parseFloat(fin_cc.Result3[0].CC_Balance);
    });
}

function addInfo (date, trans_description, deposit, expense, balance)
{
	$.get( "finance.php", {action:"insert_check", date:date, trans_description:trans_description, deposit:deposit, expense:expense, balance:balance});
	printInfo();
}

function addInfo_sa (sa_trans_dtp, sa_trans_description, sa_deposit, sa_expense, sa_balance)
{
	$.get( "finance.php", {action:"insert_saving", sa_trans_dtp:sa_trans_dtp, sa_trans_description:sa_trans_description, sa_deposit:sa_deposit, sa_expense:sa_expense, sa_balance:sa_balance});
	printInfo();
}

function addInfo_cc (cc_trans_dtp, cc_trans_description, cc_deposit, cc_expense, cc_balance)
{
	$.get( "finance.php", {action:"insert_cc", cc_trans_dtp:cc_trans_dtp, cc_trans_description:cc_trans_description, cc_deposit:cc_deposit, cc_expense:cc_expense, cc_balance:cc_balance});
	printInfo();
}

$(document).ready(function(){
    printInfo();
	$("#addInfo").click(function(e){
		var balance = 0;
		$balance = ((parseFloat($("#deposit").val()) + parseFloat(carryOver)) - parseFloat($("#expense").val()));//parse float
        addInfo($("#date").val(), $("#trans_description").val(), $("#deposit").val(), $("#expense").val(), $balance);

    });
	
	$("#addInfo_sa").click(function(e){
		var sa_balance = 0;
		$sa_balance = ((parseFloat($("#sa_deposit").val()) + parseFloat(carryOver2)) - parseFloat($("#sa_expense").val()));//parse float
        addInfo_sa($("#sa_trans_dtp").val(), $("#sa_trans_description").val(), $("#sa_deposit").val(), $("#sa_expense").val(), $sa_balance);

	  
    });
	
	$("#addInfo_cc").click(function(e){
		var cc_balance = 0;
		$cc_balance = ((parseFloat($("#cc_deposit").val()) + parseFloat(carryOver3)) - parseFloat($("#cc_expense").val()));//parse float
        addInfo_cc($("#cc_trans_dtp").val(), $("#cc_trans_description").val(), $("#cc_deposit").val(), $("#cc_expense").val(), $cc_balance);

	  
    });
	

	
});

  var linkHandler = Plaid.create({
    env: 'tartan',
    clientName: 'Client Name',
    key: 'test_key',
    product: 'auth',

    onLoad: function() {

    },
    onSuccess: function(public_token, metadata) {

    },
    onExit: function() {
      // The user exited the Link flow.
    }
  });

  // Trigger the BofA login view
  document.getElementById('bofaButton').onclick = function() {
    linkHandler.open('bofa');
  };

  // Trigger the standard institution select view
  document.getElementById('linkButton').onclick = function() {
    linkHandler.open();
  };