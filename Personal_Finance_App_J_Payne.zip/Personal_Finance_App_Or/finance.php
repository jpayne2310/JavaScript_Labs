<?php
    
    include ('models/database.php');
	
	if (isset($_GET['action'])) {
        $action = $_GET['action'];
    } else {
        $action = "list_check";
    }
	
	//listings for accounts and insert 
	if ($action == "list_check") {
		$query = "SELECT *
		FROM fin_check
		ORDER BY Trans_ID DESC
		Limit 5";
		$statement = $db->prepare ($query);
		$success = $statement->execute();
		$rows = $statement->fetchAll(PDO::FETCH_ASSOC);
   
		echo json_encode(array('Result' => $rows));
	}
	
	else if ($action == "insert_check") {
		$date = $_GET['date'];
		$trans_description = $_GET['trans_description'];
        $deposit = $_GET['deposit'];
        $expense = $_GET['expense'];
        $balance = $_GET['balance'];
		
		$query = "INSERT INTO fin_check (Date, Trans_Description, Deposit, Expense, Balance) VALUES (:date, :trans_description, :deposit, :expense, :balance)";
		$statement = $db->prepare ($query);
		$statement->bindValue (":date", $date);
		$statement->bindValue (":trans_description", $trans_description);
        $statement->bindValue (":deposit", $deposit);
        $statement->bindValue (":expense", $expense);
        $statement->bindValue (":balance", $balance);
		$success = $statement->execute();
	}
        
    if ($action == "list_saving") {
		$query = "SELECT *
		FROM fin_saving
		ORDER BY SA_Trans_ID DESC
		Limit 5";
		$statement = $db->prepare ($query);
		$success = $statement->execute();
		$rows = $statement->fetchAll(PDO::FETCH_ASSOC);
   
		echo json_encode(array('Result2' => $rows));
	}
	
	else if ($action == "insert_saving") {
		$sa_trans_dtp = $_GET['sa_trans_dtp'];
		$sa_trans_description = $_GET['sa_trans_description'];
        $sa_deposit = $_GET['sa_deposit'];
        $sa_expense = $_GET['sa_expense'];
        $sa_balance = $_GET['sa_balance'];
		
		$query = "INSERT INTO fin_saving (SA_Trans_DTP, SA_Trans_Description, SA_Deposit, SA_Expense, SA_Balance) VALUES (:sa_trans_dtp, :sa_trans_description, :sa_deposit, :sa_expense, :sa_balance)";
		$statement = $db->prepare ($query);
		$statement->bindValue (":sa_trans_dtp", $sa_trans_dtp);
		$statement->bindValue (":sa_trans_description", $sa_trans_description);
        $statement->bindValue (":sa_deposit", $sa_deposit);
        $statement->bindValue (":sa_expense", $sa_expense);
        $statement->bindValue (":sa_balance", $sa_balance);
		$success = $statement->execute();
	}

    if ($action == "list_cc") {
		$query = "SELECT *
		FROM fin_cc
		ORDER BY CC_Trans_ID DESC
		Limit 5";
		$statement = $db->prepare ($query);
		$success = $statement->execute();
		$rows = $statement->fetchAll(PDO::FETCH_ASSOC);
   
		echo json_encode(array('Result3' => $rows));
	}
	
	else if ($action == "insert_cc") {
		$cc_trans_dtp = $_GET['cc_trans_dtp'];
		$cc_trans_description = $_GET['cc_trans_description'];
        $cc_deposit = $_GET['cc_deposit'];
        $cc_expense = $_GET['cc_expense'];
        $cc_balance = $_GET['cc_balance'];
		
		$query = "INSERT INTO fin_cc (CC_Trans_DTP, CC_Trans_Description, CC_Deposit, CC_Expense, CC_Balance) VALUES (:cc_trans_dtp, :cc_trans_description, :cc_deposit, :cc_expense, :cc_balance)";
		$statement = $db->prepare ($query);
		$statement->bindValue (":cc_trans_dtp", $cc_trans_dtp);
		$statement->bindValue (":cc_trans_description", $cc_trans_description);
        $statement->bindValue (":cc_deposit", $cc_deposit);
        $statement->bindValue (":cc_expense", $cc_expense);
        $statement->bindValue (":cc_balance", $cc_balance);
		$success = $statement->execute();
	}
?>