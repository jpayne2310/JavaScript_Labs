<?php
    
    include ('database.php');
	
	if (isset($_GET['action'])) {
        $action = $_GET['action'];
    } else {
        $action = "list";
    }
	
	//list top 5 scores
	if ($action == "list") {
	
		$query = "SELECT name, score
		FROM scores
		ORDER BY score DESC
		LIMIT 5";
		$statement = $db->prepare ($query);
		$success = $statement->execute();
		$rows = $statement->fetchAll(PDO::FETCH_ASSOC);

   
		echo json_encode(array('Result' => $rows));
	}
	
	else if ($action == "insert") {
		$name = $_GET['name'];
		$score = $_GET['score'];
		
		$query = "INSERT INTO scores (name, score) VALUES (:name, :score)";
		$statement = $db->prepare ($query);
		$statement->bindValue (":name", $name);
		$statement->bindValue (":score", $score);
		$success = $statement->execute();
		
		echo "this worked";
		
	}
?>