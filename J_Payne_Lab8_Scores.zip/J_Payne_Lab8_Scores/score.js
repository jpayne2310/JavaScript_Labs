
function printScore()
{
	var str = "";
	var str2 = "";
	
	$.getJSON( "score2.php", {action:"list"},  function( scores ) {
		for (i=0; i< scores.Result.length; i++)
        {
			str += scores.Result[i].name;
			$("#results").html(str);
			str2 += scores.Result[i].score
			$("#results2").html(str2);
			str += "<br>";
			str2 += "<br>";
		}

		$("#results").html(str);
		
    });
	
}

function addScore (name, score)
{
	$.get( "score2.php", {action:"insert", name: name, score:score});
	printScore();
}

$(document).ready(function(){
    printScore();
	
	$("#addScore").click(function(e){
        addScore($("#name").val(), $("#score").val());
			   //enable the rerun option

	   location.reload();
	  
    });
});